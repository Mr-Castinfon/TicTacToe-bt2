package com.example.esp;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private Button btnSelectDevice, btnConnect, btnOn, btnOff;
    private TextView tvOutput;

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket bluetoothSocket;
    private OutputStream outputStream;
    private InputStream inputStream;

    private boolean isConnected = false;
    private boolean isCountDevice = false;
    private String selectedDeviceName = null;
    private final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSelectDevice = findViewById(R.id.btnSelectDevice);
        btnConnect = findViewById(R.id.btnConnect);
        btnOn = findViewById(R.id.btnOn);
        btnOff = findViewById(R.id.btnOff);
        tvOutput = findViewById(R.id.tvOutput);

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        // "Select Device" gumb za prikaz popisa uparenih uređaja
        btnSelectDevice.setOnClickListener(v -> showDevicePicker());

        btnConnect.setOnClickListener(v -> connectToSelectedDevice());

        btnOn.setOnClickListener(v -> sendData("1\n"));  // Za ON šaljemo "1"
        btnOff.setOnClickListener(v -> sendData("0\n")); // Za OFF šaljemo "0"

    }

    private void showDevicePicker() {
        // Provjera dozvola prije nego nastavimo
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // Ako dozvola nije dodijeljena, pitamo korisnika za dozvolu
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.BLUETOOTH_CONNECT, android.Manifest.permission.ACCESS_FINE_LOCATION},
                    1);  // requestCode 1
            return;
        }

        // Dohvat uparenih uređaja
        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        if (pairedDevices.isEmpty()) {
            Toast.makeText(this, "No paired devices found", Toast.LENGTH_SHORT).show();
            return;
        }

        // Popis imena svih uparenih uređaja
        List<String> deviceNames = new ArrayList<>();
        for (BluetoothDevice device : pairedDevices) {
            deviceNames.add(device.getName());
        }

        // Prikazivanje AlertDialog sa popisom uređaja
        new AlertDialog.Builder(this)
                .setTitle("Choose Bluetooth Device")
                .setItems(deviceNames.toArray(new String[0]), (dialog, which) -> {
                    selectedDeviceName = deviceNames.get(which);
                    Toast.makeText(this, "Selected: " + selectedDeviceName, Toast.LENGTH_SHORT).show();
                    // Pozivanje funkcije za povezivanje
                    connectToSelectedDevice();
                })
                .show();
    }


    private void connectToSelectedDevice() {
        if (selectedDeviceName == null) {
            Toast.makeText(this, "Select a device first", Toast.LENGTH_SHORT).show();
            return;
        }

        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        BluetoothDevice device = findDeviceByName(pairedDevices, selectedDeviceName);

        if (device == null) {
            Toast.makeText(this, "Device not found", Toast.LENGTH_SHORT).show();
            return;
        }

        BluetoothDevice finalDevice = device;
        new Thread(() -> {
            try {
                bluetoothSocket = finalDevice.createRfcommSocketToServiceRecord(SPP_UUID);
                bluetoothSocket.connect();

                outputStream = bluetoothSocket.getOutputStream();
                inputStream = bluetoothSocket.getInputStream();

                isConnected = true;

                runOnUiThread(() -> Toast.makeText(this, "Connected to " + selectedDeviceName, Toast.LENGTH_SHORT).show());

                isCountDevice = selectedDeviceName.contains("Counter");

                if (isCountDevice) {
                    // Ako je to "Counter" uređaj, samo slušaj sekunde, nemoj slati podatke
                    startListeningForSeconds();
                }

            } catch (IOException e) {
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(this, "Connection failed", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private void startListeningForSeconds() {
        new Thread(() -> {
            byte[] buffer = new byte[1024];
            int bytes;

            while (isConnected) {
                try {
                    bytes = inputStream.read(buffer);

                    if (bytes > 0) {
                        String incoming = new String(buffer, 0, bytes);

                        runOnUiThread(() -> tvOutput.setText("Seconds: " + incoming.trim()));
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    break;
                }
            }
        }).start();
    }



    private BluetoothDevice findDeviceByName(Set<BluetoothDevice> pairedDevices, String deviceName) {
        // Check for Bluetooth permissions before proceeding
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            // Prompt the user to grant permission, e.g., request permission here.
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.BLUETOOTH_CONNECT}, 1);
            return null;  // Permission not granted, return null or handle accordingly
        }

        // If permission is granted, proceed to find the device
        for (BluetoothDevice device : pairedDevices) {
            if (device.getName().equals(deviceName)) {
                return device;
            }
        }
        return null;  // Device not found
    }

    private void sendData(String data) {
        if (!isConnected) return;
        try {
            outputStream.write(data.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (bluetoothSocket != null) bluetoothSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
